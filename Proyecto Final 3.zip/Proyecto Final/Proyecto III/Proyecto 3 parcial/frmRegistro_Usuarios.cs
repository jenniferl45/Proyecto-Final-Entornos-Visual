﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Proyecto_3_parcial
{
    public partial class frmRegistro_Usuarios : Form
    {
        clsConexionBD conexionBD = new clsConexionBD();
        clsRegistro registro = new clsRegistro();

        public frmRegistro_Usuarios()
        {
            InitializeComponent();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            
            if (txtUsuario.Text == "" || txtContraseña.Text == "" || txtCorreo.Text == "" || cmbPregunta.Text == "" || txtRespuesta.Text == "")
            {
                MessageBox.Show("Por favor, complete todos los campos obligatorios.");  // Si hay alguno vacío no te deja pasar.
                return;
            }
            else
            {
                int rol = txtClave.Text == "ganador" ? 1 : 2;   // Asigna el rol dependiendo si ingresa la clave correcta.
                int estado = 1; // Predeterminado estado será 1 que es activo/no ha votado. Todavía tiene permiso de entrar.

                // Usar los métodos de la clase clsRegistro para establecer los valores
                registro.setUsuario(txtUsuario.Text.Trim());
                registro.setContraseña(txtContraseña.Text);
                registro.setCorreo(txtCorreo.Text);
                registro.setPregunta(cmbPregunta.Text);
                registro.setRespuesta(txtRespuesta.Text);

                string query = "INSERT INTO Usuarios (Nombre_Usuario, Contraseña_Usuario, Correo_Usuario, Pregunta_Recuperacion, Respuesta_Recuperacion, Rol, Estado) " +
                               "VALUES (@Usuario, @Contraseña, @Correo, @PreguntaSeguridad, @RespuestaSeguridad, @Rol, @Estado)";   // Consulta SQL para insertar a la tabla usuarios.
                SqlParameter[] parametros = new SqlParameter[]
                {
                new SqlParameter("@Usuario", registro.getUsuario()),  // Indicamos que los parámetros son los valores de la clase clsRegistro.
                new SqlParameter("@Contraseña", registro.getContraseña()),
                new SqlParameter("@Correo", registro.getCorreo()),
                new SqlParameter("@PreguntaSeguridad", registro.getPregunta()),
                new SqlParameter("@RespuestaSeguridad", registro.getRespuesta()),
                new SqlParameter("@Rol", rol),
                new SqlParameter("@Estado", estado)
                };

                if (conexionBD.EjecutarComando(query, parametros))  // Si logró ejecutar el query SQL correctamente.
                {
                    MessageBox.Show("Usuario registrado correctamente");
                    txtUsuario.Clear();
                    txtContraseña.Clear();
                    txtCorreo.Clear();
                    cmbPregunta.SelectedIndex = -1;
                    txtRespuesta.Clear();
                    txtClave.Clear();

                    this.Hide();
                    Form1 inicio = new Form1(); // Devuelve a nuestro formulario de inicio de sesión.
                    inicio.Show();
                }
                else
                {
                    MessageBox.Show("Error al registrar el usuario");
                }
            }
        }

        private void frmRegistro_Usuarios_Load(object sender, EventArgs e)
        {
            cmbPregunta.SelectedIndex = -1;
        }
    }
}
