﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_3_parcial
{
    public class clsUsuario
    {
        private string nombreUsuario;
        private int rol;

        public clsUsuario(string nombreUsuario, int rol)
        {
            this.nombreUsuario = nombreUsuario;
            this.rol = rol;
        }

        public string getNombreUsuario() { return nombreUsuario; }
        public int getRol() { return rol; }

    }
}
