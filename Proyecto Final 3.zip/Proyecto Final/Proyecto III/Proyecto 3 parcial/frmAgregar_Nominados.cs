﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;        //para convertir la imagen que subiremos a un array de bytes compatible con sql.

namespace Proyecto_3_parcial
{
    public partial class frmAgregar_Nominados : Form
    {
        private clsPelicula pelicula = new clsPelicula();

        public frmAgregar_Nominados()
        {
            InitializeComponent();
        }

        private void LlenarComboBoxCategorias()
        {
            clsConexionBD conexion = new clsConexionBD();
            try
            {
                using (SqlConnection cn = new SqlConnection(conexion.Cadena()))
                {
                    cn.Open();
                    if (cn.State == ConnectionState.Open)
                    {
                        string queryCategoria = "SELECT Nombre_Categoria FROM Categoria";
                        using (SqlCommand comando = new SqlCommand(queryCategoria, cn))
                        {
                            using (SqlDataReader reader = comando.ExecuteReader())
                            {
                                cmbCategoria.Items.Clear();

                                while (reader.Read())
                                {
                                    string nombreCategoria = reader["Nombre_Categoria"].ToString();
                                    cmbCategoria.Items.Add(nombreCategoria);
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error de conexión.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar conectar: " + ex.Message);
            }
        }

        public void CargarCategoria()
        {
            clsConexionBD conexion = new clsConexionBD();

            try
            {
                using (SqlConnection cn = new SqlConnection(conexion.Cadena()))
                {
                    cn.Open();
                    if (cn.State == ConnectionState.Open)
                    {
                        string queryCategoria = "SELECT Nombre_Categoria FROM Categoria";
                        using (SqlCommand comando = new SqlCommand(queryCategoria, cn))
                        {
                            using (SqlDataReader reader = comando.ExecuteReader())
                            {
                                cmbCategoria.Items.Clear();
                                while (reader.Read())
                                {
                                    string nombreCategoria = reader["Nombre_Categoria"].ToString();
                                    cmbCategoria.Items.Add(nombreCategoria);
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error de conexión.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar conectar: " + ex.Message);
            }
        }

        private void btnSeleccionarImagen_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                txtNombreImagen.Text = openFileDialog.FileName;
                pbImagen.Image = Image.FromFile(openFileDialog.FileName);
            }
        }

        private byte[] ImageToByteArray(Image image)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                image.Save(ms, image.RawFormat);
                return ms.ToArray();
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            
            if (txtNombre.Text == "" || txtDescripcion.Text == "" || txtNombreImagen.Text == "" || pbImagen.Image == null || cmbCategoria.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, complete todos los campos obligatorios.");
                return;
            }

            string nombre = txtNombre.Text.Trim();
            clsConexionBD conexionBD = new clsConexionBD();

            // Consulta para verificar si el nominado ya existe
            string checkQuery = "SELECT COUNT(*) FROM (" +
                                "SELECT Nombre_Pelicula AS Nombre FROM Pelicula WHERE Nombre_Pelicula = @Nombre " +
                                "UNION ALL " +
                                "SELECT Nombre_Actor AS Nombre FROM Actor WHERE Nombre_Actor = @Nombre " +
                                "UNION ALL " +
                                "SELECT Nombre_Director AS Nombre FROM Director WHERE Nombre_Director = @Nombre" +
                                ") AS Nominados WHERE Nombre = @Nombre";

            SqlParameter[] revisar = new SqlParameter[]
            {
                new SqlParameter("@Nombre", nombre)
            };

            try
            {
                int count = (int)conexionBD.Consulta_unico_valor(checkQuery, revisar);
                if (count > 0)
                {
                    MessageBox.Show("Este nominado ya ha sido ingresado anteriormente. Favor comprobar los datos.");
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al verificar existencia del nominado: " + ex.Message);
                return;
            }

            // Usar los métodos de la clase clsPelicula para establecer los valores
            pelicula.setNombre(nombre);
            pelicula.setDescripcion(txtDescripcion.Text.Trim());
            pelicula.setNombrePoster(Path.GetFileName(txtNombreImagen.Text));
            pelicula.setPoster(ImageToByteArray(pbImagen.Image));
            pelicula.setCategoria(cmbCategoria.SelectedIndex + 1); // Ajustar según sea necesario

            string query = "";
            int selectedIndex = cmbCategoria.SelectedIndex;

            // Utilizar el índice seleccionado del ComboBox para determinar la consulta SQL
            if (selectedIndex == 0)
            {
                query = "INSERT INTO Pelicula (Nombre_Pelicula, Descripcion_Pelicula, Nombre_Poster_Pelicula, Poster_Pelicula, ID_Categoria) " +
                        "VALUES (@Nombre, @Descripcion, @NombrePoster, @Poster, @Categoria)";
            }
            else if (selectedIndex == 1)
            {
                query = "INSERT INTO Actor (Nombre_Actor, Descripcion_Actor, Nombre_Foto_Actor, Foto_Actor, ID_Categoria) " +
                        "VALUES (@Nombre, @Descripcion, @NombrePoster, @Poster, @Categoria)";
            }
            else if (selectedIndex == 2)
            {
                query = "INSERT INTO Director (Nombre_Director, Descripcion_Director, Nombre_Foto_Director, Foto_Director, ID_Categoria) " +
                        "VALUES (@Nombre, @Descripcion, @NombrePoster, @Poster, @Categoria)";
            }

            SqlParameter[] parametros = new SqlParameter[]
            {
                new SqlParameter("@Nombre", pelicula.getNombre()),
                new SqlParameter("@Descripcion", pelicula.getDescripcion()),
                new SqlParameter("@NombrePoster", pelicula.getNombrePoster()),
                new SqlParameter("@Poster", pelicula.getPoster()),
                new SqlParameter("@Categoria", pelicula.getCategoria())
            };

            if (conexionBD.EjecutarComando(query, parametros))
            {
                MessageBox.Show(cmbCategoria.Text + " registrado correctamente");
                txtNombre.Clear();
                txtDescripcion.Clear();
                txtNombreImagen.Clear();
                pbImagen.Image = null;
                cmbCategoria.SelectedIndex = -1;
            }
            else
            {
                MessageBox.Show("Error al registrar " + cmbCategoria.Text);
            }
        }

        private void frmAgregar_Nominados_Load(object sender, EventArgs e)
        {
            CargarCategoria();

        }

        private void cmbCategoria_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 inicio = new Form1(); // Devuelve a nuestro formulario de inicio de sesión.
            inicio.Show();
        }
    }
}
