﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Proyecto_3_parcial
{
    public partial class frmMejor_Actor : Form
    {
        private clsUsuario usuarioLogueado;
        public frmMejor_Actor(clsUsuario usuario)
        {
            InitializeComponent();
            usuarioLogueado = usuario;
        }

        
        public void CargarCategoria()
        {
            clsConexionBD conexion = new clsConexionBD();

            try
            {
                using (SqlConnection cn = new SqlConnection(conexion.Cadena()))
                {
                    cn.Open();
                    if (cn.State == ConnectionState.Open)
                    {
                        string queryCategoria = "SELECT Nombre_Actor FROM Actor";
                        using (SqlCommand comando = new SqlCommand(queryCategoria, cn))
                        {
                            using (SqlDataReader reader = comando.ExecuteReader())
                            {
                                cmbActor.Items.Clear();
                                while (reader.Read())
                                {
                                    string nombreActor = reader["Nombre_Actor"].ToString();
                                    cmbActor.Items.Add(nombreActor);
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error de conexión.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar conectar: " + ex.Message);
            }
        }

        private void CargarDetallesPelicula(string nombreActor)
        {
            clsConexionBD conexion = new clsConexionBD();

            try
            {
                using (SqlConnection cn = new SqlConnection(conexion.Cadena()))
                {
                    cn.Open();
                    if (cn.State == ConnectionState.Open)
                    {
                        string queryDetalles = "SELECT Descripcion_Actor, Foto_Actor FROM Actor WHERE Nombre_Actor = @NombreActor";
                        using (SqlCommand comando = new SqlCommand(queryDetalles, cn))
                        {
                            comando.Parameters.AddWithValue("@NombreActor", nombreActor);

                            using (SqlDataReader reader = comando.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    string descripcion = reader["Descripcion_Actor"].ToString();
                                    byte[] imagenBytes = (byte[])reader["Foto_Actor"];

                                    // Mostrar la descripción en el RichTextBox
                                    rtxtDescripcion.Text = descripcion;

                                    // Mostrar la imagen en el panel
                                    using (MemoryStream ms = new MemoryStream(imagenBytes))
                                    {
                                        panel1.BackgroundImage = Image.FromStream(ms);
                                        panel1.BackgroundImageLayout = ImageLayout.Zoom;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error de conexión.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar conectar: " + ex.Message);
            }
        }

        private void ActualizarVotos(string nombrePelicula)
        {
            clsConexionBD conexion = new clsConexionBD();

            try
            {
                using (SqlConnection cn = new SqlConnection(conexion.Cadena()))
                {
                    cn.Open();
                    if (cn.State == ConnectionState.Open)
                    {
                        // Primero obtenemos el ID de la película seleccionada
                        string queryID = "SELECT ID_Pelicula FROM Pelicula WHERE Nombre_Pelicula = @NombrePelicula";
                        int idPelicula = 0;

                        using (SqlCommand comandoID = new SqlCommand(queryID, cn))
                        {
                            comandoID.Parameters.AddWithValue("@NombrePelicula", nombrePelicula);

                            using (SqlDataReader reader = comandoID.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    idPelicula = (int)reader["ID_Pelicula"];
                                    MessageBox.Show("ID de la película obtenida: " + idPelicula);
                                }
                                else
                                {
                                    MessageBox.Show("No se encontró la película seleccionada.");
                                    return;
                                }
                            }
                        }

                        if (idPelicula != 0)
                        {
                            // Ahora actualizamos el recuento de votos para esa película
                            string queryActualizarVotos = "UPDATE Votos SET Recuento_Votos = Recuento_Votos + 1 WHERE ID_Pelicula = @IDPelicula";

                            using (SqlCommand comandoActualizar = new SqlCommand(queryActualizarVotos, cn))
                            {
                                comandoActualizar.Parameters.AddWithValue("@IDPelicula", idPelicula);
                                int filasAfectadas = comandoActualizar.ExecuteNonQuery();

                                if (filasAfectadas > 0)
                                {
                                    MessageBox.Show("¡Voto registrado exitosamente!");
                                }
                                else
                                {
                                    MessageBox.Show("Error al registrar el voto. No se encontró la película en la tabla de votos.");
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Error al obtener el ID de la película.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error de conexión.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar conectar: " + ex.Message);
            }
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            clsConexionBD conexion = new clsConexionBD();
            string nombreActorSeleccionado = cmbActor.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(nombreActorSeleccionado))
            {
                MessageBox.Show("Por favor, seleccione un actor.");
                return;
            }

            // Consulta para obtener el ID del actor seleccionado
            string queryIdActor = "SELECT ID_Actor FROM Actor WHERE Nombre_Actor = @NombreActor";
            SqlParameter[] parametrosIdActor = { new SqlParameter("@NombreActor", nombreActorSeleccionado) };

            int idActor = -1;
            try
            {
                idActor = (int)conexion.Consulta_unico_valor(queryIdActor, parametrosIdActor);

                // Consulta para actualizar el recuento de votos
                string queryActualizarVotos = "UPDATE Actor SET Recuento_Votos = ISNULL(Recuento_Votos, 0) + 1 WHERE ID_Actor = @ID_Actor";
                SqlParameter[] parametrosActualizarVotos = { new SqlParameter("@ID_Actor", idActor) };

                if (conexion.EjecutarComando(queryActualizarVotos, parametrosActualizarVotos))
                {
                    MessageBox.Show("Voto registrado correctamente.");
                    this.Hide();
                    // Aquí puedes abrir el formulario de nominaciones si es necesario
                }
                else
                {
                    MessageBox.Show("Error al registrar el voto, por favor intente de nuevo.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }


        }

        private void frmMejor_Pelicula_Load(object sender, EventArgs e)
        {
            cmbActor.SelectedIndex = -1;
            CargarCategoria();
        }

        private void cmbPelicula_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbActor.SelectedIndex != -1)
            {
                string nombrePeliculaSeleccionada = cmbActor.SelectedItem.ToString();
                CargarDetallesPelicula(nombrePeliculaSeleccionada);
            }
        }
    }
}
