﻿namespace Proyecto_3_parcial
{
    partial class frmEstadisiticas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.dgvPelicula = new System.Windows.Forms.DataGridView();
            this.dgvActor = new System.Windows.Forms.DataGridView();
            this.dgvDirector = new System.Windows.Forms.DataGridView();
            this.chPelicula = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chActor = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chDirector = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnRegresar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPelicula)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvActor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDirector)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chPelicula)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chActor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chDirector)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvPelicula
            // 
            this.dgvPelicula.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPelicula.Location = new System.Drawing.Point(37, 37);
            this.dgvPelicula.Name = "dgvPelicula";
            this.dgvPelicula.RowTemplate.Height = 24;
            this.dgvPelicula.Size = new System.Drawing.Size(725, 159);
            this.dgvPelicula.TabIndex = 0;
            // 
            // dgvActor
            // 
            this.dgvActor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvActor.Location = new System.Drawing.Point(37, 225);
            this.dgvActor.Name = "dgvActor";
            this.dgvActor.RowTemplate.Height = 24;
            this.dgvActor.Size = new System.Drawing.Size(725, 170);
            this.dgvActor.TabIndex = 1;
            // 
            // dgvDirector
            // 
            this.dgvDirector.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDirector.Location = new System.Drawing.Point(37, 422);
            this.dgvDirector.Name = "dgvDirector";
            this.dgvDirector.RowTemplate.Height = 24;
            this.dgvDirector.Size = new System.Drawing.Size(725, 159);
            this.dgvDirector.TabIndex = 2;
            // 
            // chPelicula
            // 
            chartArea1.Name = "ChartArea1";
            this.chPelicula.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chPelicula.Legends.Add(legend1);
            this.chPelicula.Location = new System.Drawing.Point(806, 37);
            this.chPelicula.Name = "chPelicula";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chPelicula.Series.Add(series1);
            this.chPelicula.Size = new System.Drawing.Size(455, 159);
            this.chPelicula.TabIndex = 3;
            this.chPelicula.Text = "chart1";
            // 
            // chActor
            // 
            chartArea2.Name = "ChartArea1";
            this.chActor.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chActor.Legends.Add(legend2);
            this.chActor.Location = new System.Drawing.Point(806, 225);
            this.chActor.Name = "chActor";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chActor.Series.Add(series2);
            this.chActor.Size = new System.Drawing.Size(455, 159);
            this.chActor.TabIndex = 3;
            this.chActor.Text = "chart1";
            // 
            // chDirector
            // 
            chartArea3.Name = "ChartArea1";
            this.chDirector.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.chDirector.Legends.Add(legend3);
            this.chDirector.Location = new System.Drawing.Point(806, 422);
            this.chDirector.Name = "chDirector";
            series3.ChartArea = "ChartArea1";
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            this.chDirector.Series.Add(series3);
            this.chDirector.Size = new System.Drawing.Size(455, 159);
            this.chDirector.TabIndex = 3;
            this.chDirector.Text = "chart1";
            // 
            // btnRegresar
            // 
            this.btnRegresar.Location = new System.Drawing.Point(646, 588);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(142, 37);
            this.btnRegresar.TabIndex = 4;
            this.btnRegresar.Text = "Regresar";
            this.btnRegresar.UseVisualStyleBackColor = true;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // frmEstadisiticas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gold;
            this.ClientSize = new System.Drawing.Size(1303, 637);
            this.Controls.Add(this.btnRegresar);
            this.Controls.Add(this.chDirector);
            this.Controls.Add(this.chActor);
            this.Controls.Add(this.chPelicula);
            this.Controls.Add(this.dgvDirector);
            this.Controls.Add(this.dgvActor);
            this.Controls.Add(this.dgvPelicula);
            this.Name = "frmEstadisiticas";
            this.Text = "frmEstadisiticas";
            this.Load += new System.EventHandler(this.frmEstadisiticas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPelicula)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvActor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDirector)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chPelicula)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chActor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chDirector)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvPelicula;
        private System.Windows.Forms.DataGridView dgvActor;
        private System.Windows.Forms.DataGridView dgvDirector;
        private System.Windows.Forms.DataVisualization.Charting.Chart chPelicula;
        private System.Windows.Forms.DataVisualization.Charting.Chart chActor;
        private System.Windows.Forms.DataVisualization.Charting.Chart chDirector;
        private System.Windows.Forms.Button btnRegresar;
    }
}