﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_3_parcial
{
    // Homonimia: clsActor representa un actor nominado al Oscar
    class clsActor : clsNominaciones
    {
        // Constructor por defecto
        public clsActor() { }

        // Constructor con parámetros, llamando al constructor de la superclase
        public clsActor(int id, string nombre, string descripcion, string foto, string nombreFoto, int idCategoria)
            : base(id, nombre, descripcion, foto, nombreFoto, idCategoria)
        {
        }

        // Función virtual sobrescrita para mostrar un mensaje específico de Actor
        public override void mensaje()
        {
            MessageBox.Show($"Actor: {Nombre}\n" +
                            $"Descripción: {Descripcion}\n" +
                            $"Foto: {Foto}");
        }
    }
}
