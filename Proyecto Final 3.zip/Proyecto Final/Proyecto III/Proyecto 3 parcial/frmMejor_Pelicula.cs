﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Proyecto_3_parcial
{
    public partial class frmMejor_Pelicula : Form
    {
        private clsUsuario usuarioLogueado;
        public frmMejor_Pelicula(clsUsuario usuario)
        {
            InitializeComponent();
            usuarioLogueado = usuario;
        }

        
        public void CargarCategoria()
        {
            clsConexionBD conexion = new clsConexionBD();

            try
            {
                using (SqlConnection cn = new SqlConnection(conexion.Cadena()))
                {
                    cn.Open();
                    if (cn.State == ConnectionState.Open)
                    {
                        string queryCategoria = "SELECT Nombre_Pelicula FROM Pelicula";
                        using (SqlCommand comando = new SqlCommand(queryCategoria, cn))
                        {
                            using (SqlDataReader reader = comando.ExecuteReader())
                            {
                                cmbPelicula.Items.Clear();
                                while (reader.Read())
                                {
                                    string nombrePelicula = reader["Nombre_Pelicula"].ToString();
                                    cmbPelicula.Items.Add(nombrePelicula);
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error de conexión.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar conectar: " + ex.Message);
            }
        }

        private void CargarDetallesPelicula(string nombrePelicula)
        {
            clsConexionBD conexion = new clsConexionBD();

            try
            {
                using (SqlConnection cn = new SqlConnection(conexion.Cadena()))
                {
                    cn.Open();
                    if (cn.State == ConnectionState.Open)
                    {
                        string queryDetalles = "SELECT Descripcion_Pelicula, Poster_Pelicula FROM Pelicula WHERE Nombre_Pelicula = @NombrePelicula";
                        using (SqlCommand comando = new SqlCommand(queryDetalles, cn))
                        {
                            comando.Parameters.AddWithValue("@NombrePelicula", nombrePelicula);

                            using (SqlDataReader reader = comando.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    string descripcion = reader["Descripcion_Pelicula"].ToString();
                                    byte[] imagenBytes = (byte[])reader["Poster_Pelicula"];

                                    // Mostrar la descripción en el RichTextBox
                                    rtxtDescripcion.Text = descripcion;

                                    // Mostrar la imagen en el panel
                                    using (MemoryStream ms = new MemoryStream(imagenBytes))
                                    {
                                        panel1.BackgroundImage = Image.FromStream(ms);
                                        panel1.BackgroundImageLayout = ImageLayout.Zoom;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error de conexión.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar conectar: " + ex.Message);
            }
        }

        private void ActualizarVotos(string nombrePelicula)
        {
            clsConexionBD conexion = new clsConexionBD();

            try
            {
                using (SqlConnection cn = new SqlConnection(conexion.Cadena()))
                {
                    cn.Open();
                    if (cn.State == ConnectionState.Open)
                    {
                        // Primero obtenemos el ID de la película seleccionada
                        string queryID = "SELECT ID_Pelicula FROM Pelicula WHERE Nombre_Pelicula = @NombrePelicula";
                        int idPelicula = 0;

                        using (SqlCommand comandoID = new SqlCommand(queryID, cn))
                        {
                            comandoID.Parameters.AddWithValue("@NombrePelicula", nombrePelicula);

                            using (SqlDataReader reader = comandoID.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    idPelicula = (int)reader["ID_Pelicula"];
                                    MessageBox.Show("ID de la película obtenida: " + idPelicula);
                                }
                                else
                                {
                                    MessageBox.Show("No se encontró la película seleccionada.");
                                    return;
                                }
                            }
                        }

                        if (idPelicula != 0)
                        {
                            // Ahora actualizamos el recuento de votos para esa película
                            string queryActualizarVotos = "UPDATE Votos SET Recuento_Votos = Recuento_Votos + 1 WHERE ID_Pelicula = @IDPelicula";

                            using (SqlCommand comandoActualizar = new SqlCommand(queryActualizarVotos, cn))
                            {
                                comandoActualizar.Parameters.AddWithValue("@IDPelicula", idPelicula);
                                int filasAfectadas = comandoActualizar.ExecuteNonQuery();

                                if (filasAfectadas > 0)
                                {
                                    MessageBox.Show("¡Voto registrado exitosamente!");
                                }
                                else
                                {
                                    MessageBox.Show("Error al registrar el voto. No se encontró la película en la tabla de votos.");
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Error al obtener el ID de la película.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error de conexión.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar conectar: " + ex.Message);
            }
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            clsConexionBD conexion = new clsConexionBD();
            string nombrePeliculaSeleccionada = cmbPelicula.SelectedItem.ToString();

            // Consulta para obtener el ID de la película seleccionada
            string queryIdPelicula = "SELECT ID_Pelicula FROM Pelicula WHERE Nombre_Pelicula = @NombrePelicula";
            SqlParameter[] parametrosIdPelicula = { new SqlParameter("@NombrePelicula", nombrePeliculaSeleccionada) };

            int idPelicula = -1;
            try
            {
                idPelicula = (int)conexion.Consulta_unico_valor(queryIdPelicula, parametrosIdPelicula);

                // Consulta para actualizar el recuento de votos
                string queryActualizarVotos = "UPDATE Pelicula SET Recuento_Votos = Recuento_Votos + 1 WHERE ID_Pelicula = @ID_Pelicula";
                SqlParameter[] parametrosActualizarVotos = { new SqlParameter("@ID_Pelicula", idPelicula) };

                if (conexion.EjecutarComando(queryActualizarVotos, parametrosActualizarVotos))
                {
                    MessageBox.Show("Voto registrado correctamente.");
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Error al registrar el voto, por favor intente de nuevo.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }



        }

        private void frmMejor_Pelicula_Load(object sender, EventArgs e)
        {
            cmbPelicula.SelectedIndex = -1;
            CargarCategoria();
        }

        private void cmbPelicula_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbPelicula.SelectedIndex != -1)
            {
                string nombrePeliculaSeleccionada = cmbPelicula.SelectedItem.ToString();
                CargarDetallesPelicula(nombrePeliculaSeleccionada);
            }
        }
    }
}
