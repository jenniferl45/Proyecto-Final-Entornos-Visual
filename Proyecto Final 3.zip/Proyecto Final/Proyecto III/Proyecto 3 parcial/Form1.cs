﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Proyecto_3_parcial
{
    public partial class Form1 : Form
    {
        clsConexionBD conexionBD = new clsConexionBD();
        private clsUsuario usuarioLogueado;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            frmRegistro_Usuarios registro = new frmRegistro_Usuarios(); //muestra form para registrar el usuario.
            registro.Show();
            this.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void btnIsesion_Click(object sender, EventArgs e)
        {

            if (txtUsuario.Text == "" || txtContraseña.Text == "")
            {
                MessageBox.Show("Por favor, ingrese el usuario y la contraseña.");
                return;
            }

            string query = "SELECT Nombre_Usuario, Rol, Estado FROM Usuarios WHERE Nombre_Usuario = @Usuario AND Contraseña_Usuario = @Contraseña";
            SqlParameter[] parametros = new SqlParameter[]
            {
            new SqlParameter("@Usuario", txtUsuario.Text),  // Indicamos que los TextBox son los datos que buscaremos en la tabla.
            new SqlParameter("@Contraseña", txtContraseña.Text)
            };

            SqlDataReader reader = null; // Lector.

            try
            {
                conexionBD.Open();
                SqlCommand comando = new SqlCommand(query, conexionBD.SqlCon);
                comando.Parameters.AddRange(parametros);
                reader = comando.ExecuteReader();   // Comando reader para buscar en la tabla.

                if (reader.Read())      // Si el lector encuentra el usuario lo deja pasar y dependiendo del rol le muestra una vista u otra.
                {
                    string nombreUsuario = reader["Nombre_Usuario"].ToString();
                    int rol = Convert.ToInt32(reader["Rol"]);
                    int estado = Convert.ToInt32(reader["Estado"]);

                    if (estado == 2)
                    {
                        MessageBox.Show("Este usuario ya ha realizado sus votos y no puede volver a votar.");
                    }
                    else
                    {
                        usuarioLogueado = new clsUsuario(nombreUsuario, rol);

                        MessageBox.Show("Bienvenido " + nombreUsuario);

                        this.Hide();

                        if (rol == 1)   // Dependiendo del rol muestra la vista de administrador o la de votante.
                        {
                            frmAdministradores frmAdmin = new frmAdministradores();
                            frmAdmin.Show();
                        }
                        else if (rol == 2)
                        {
                            frmNominaciones frmNom = new frmNominaciones(usuarioLogueado); // Pasa el objeto usuarioLogueado al formulario de nominaciones.
                            frmNom.Show();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("El usuario no existe o es incorrecto.");
                    txtUsuario.Text = "";
                    txtContraseña.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conexionBD.Close();
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            frmRecuperacion_Contraseña recu = new frmRecuperacion_Contraseña();
            recu.Show();
        }

        private void txtUsuario_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
