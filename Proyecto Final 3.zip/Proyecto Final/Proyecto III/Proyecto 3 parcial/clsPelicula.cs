﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_3_parcial
{
    // Homonimia: clsPelicula representa una película nominada al Oscar
    class clsPelicula : clsNominaciones
    {
        // Constructor por defecto
        public clsPelicula() { }

        // Constructor con parámetros, llamando al constructor de la superclase
        public clsPelicula(int id, string nombre, string descripcion, string foto, string nombreFoto, int idCategoria)
            : base(id, nombre, descripcion, foto, nombreFoto, idCategoria)
        {

        }

        // Función virtual sobrescrita para mostrar un mensaje específico de Película
        public override void mensaje()
        {
            MessageBox.Show($"Película: {Nombre}\n" +
                            $"Descripción: {Descripcion}\n" +
                            $"Foto: {Foto}");
        }

        private string nombre;
        private string descripcion;
        private string nombrePoster;
        private byte[] poster;
        private int categoria;

        public void setNombre(string value) { nombre = value; }
        public string getNombre() { return nombre; }

        public void setDescripcion(string value) { descripcion = value; }
        public string getDescripcion() { return descripcion; }

        public void setNombrePoster(string value) { nombrePoster = value; }
        public string getNombrePoster() { return nombrePoster; }

        public void setPoster(byte[] value) { poster = value; }
        public byte[] getPoster() { return poster; }

        public void setCategoria(int value) { categoria = value; }
        public int getCategoria() { return categoria; }


    }
}
